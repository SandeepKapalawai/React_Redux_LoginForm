export const UserRoles = {
  USER_ADMIN_ROLE: "USER_ADMIN_ROLE"
};

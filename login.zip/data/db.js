var jsonServer = require('json-server');
var server = jsonServer.create();
var router = jsonServer.router('./tmp/db.json');
var middlewares = jsonServer.defaults();
//var port = process.env.PORT || 5000;
var port = 3001;


server.use(middlewares);
server.use(router);
server.listen(port, function () {
  console.log('JSON Server is running');
})
